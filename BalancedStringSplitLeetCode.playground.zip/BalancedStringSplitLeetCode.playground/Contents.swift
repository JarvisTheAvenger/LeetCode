import Foundation

// https://leetcode.com/problems/split-a-string-in-balanced-strings/

func balancedStringSplit(_ s: String) -> Int {
    let array = Array(s)
    
    var count = 0
    var result = 0
    
    array.forEach { (char) in
        if char == "R" {
            count += 1
            
        } else {
            count -= 1
        }
        
        if count == 0 {
            result += 1
        }
    }
    
    return result
}

balancedStringSplit("RL")



/*
 
 RLRRLLRLRL -> 4

 RLLLLRRRLR -> 3

 LLLLRRRR -> 1

 RLRRRLLRLL -> 2
 
 */
