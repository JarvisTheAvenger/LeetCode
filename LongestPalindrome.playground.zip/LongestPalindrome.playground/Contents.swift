import UIKit

var str = "Hello, playground"

func longestPalindrome(_ s : String) -> String {
    guard s.count > 1 else { return "" }
    
    var start = 0
    var end = 0
    
    for idx in (0..<s.count) {
        let len1 = expandAroundCenter(s, idx, idx)
        let len2 = expandAroundCenter(s, idx, idx+1)
        
        let len = max(len1, len2)
        
        if len > end - start {
            start = idx - (len - 1) / 2
            end = idx + len / 2
        }
    }
    
    let range = s.index(s.startIndex, offsetBy: start)...s.index(s.startIndex, offsetBy: end+1)

    
    return String(s[range])
}


func expandAroundCenter(_ s: String, _ left: Int, _ right: Int) -> Int {
    var upperLeft = left
    var upperRight = right
    let charArray = Array(s)
    
    while (upperLeft >= 0 && upperRight < s.count && charArray[upperLeft] == charArray[upperRight]) {
        upperRight -= 1
        upperLeft += 1
    }
    
    return upperRight - upperLeft - 1
}

//longestPalindrome("babad")

