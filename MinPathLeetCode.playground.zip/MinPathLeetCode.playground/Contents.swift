import Foundation

func minPathSum(_ grid: [[Int]]) -> Int {
    if grid.count == 0 || grid[0].count == 0 { return 0 }
    if grid.count == 1 || grid[0].count == 1 { return grid[0][0] }
    
    var dpArray : [[Int]] = [[]]
    
    let rows = grid.count
    let columns = grid[0].count
    
    dpArray[0][0] = grid[0][0]
    
    for index in (1..<rows) {
         dpArray[index][0] = dpArray[index-1][0] + grid[index][0]
    }
    
    for index in (1..<columns) {
        dpArray[0][index] = dpArray[0][index-1] + grid[0][index]
    }
    
   for i in (1..<rows) {
         for j in (1..<columns) {
            dpArray[i][j] = min(dpArray[i-1][j], dpArray[i][j-1]) + grid[i][j];
        }
    }
    
    return 0
    
}

//  public int minPathSum(int[][] grid) {
//
//  if(grid.length == 0 || grid[0].length == 0){
//      return 0;
//  }
//
//  if(grid.length == 1 && grid[0].length == 1){
//      return grid[0][0];
//  }
//
//  int[][] dp = new int[grid.length][grid[0].length];
//
//  int rows = grid.length;
//  int cols = grid[0].length;
//
//  dp[0][0] = grid[0][0];
//
//
//  for(int i = 1; i < rows; i++){
//      dp[i][0] = dp[i-1][0] + grid[i][0];
//  }
//
//
//  for(int j = 1; j < cols; j++){
//      dp[0][j] = dp[0][j-1] + grid[0][j];
//  }
//
//  /** Picking the minimum of immediate left and right and adding it to the current cell value **/
//  for(int i = 1; i < rows ; i++){
//      for(int j = 1; j < cols; j++){
//          dp[i][j] = Math.min(dp[i-1][j], dp[i][j-1]) + grid[i][j];
//      }
//  }
//
//  return dp[rows-1][cols-1];
//
//  }
