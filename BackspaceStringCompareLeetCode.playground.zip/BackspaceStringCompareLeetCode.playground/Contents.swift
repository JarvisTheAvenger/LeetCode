import Foundation

func backspaceCompare(_ s: String, _ t: String) -> Bool {
    
    var sString = ""
    var tString = ""


    for char in s {
        if char == "#" {
            if !sString.isEmpty {
               sString.removeLast()
            }
        } else {
            sString.append(char)
        }
    }
    
       for char in t {
        if char == "#" {
            if !tString.isEmpty {
               tString.removeLast()
            }
        } else {
            tString.append(char)
        }
    }
    
    return sString == tString
}

backspaceCompare("a##c", "#a#c")
