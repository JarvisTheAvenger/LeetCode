import Foundation

public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}


class Solution {
    func inorderTraversal (_ root: TreeNode?) -> [Int] {
        
        var inorderArray = [Int]()
        var stack = [TreeNode]()
        
        var current = root
        
        while current != nil || !stack.isEmpty {
            
            while current != nil {
                stack.append(current!)
                current = current!.left
            }
            
            current = stack.removeLast()
            inorderArray.append(current!.val)
            current = current?.right
        }
    
        return inorderArray
    }
    
}

