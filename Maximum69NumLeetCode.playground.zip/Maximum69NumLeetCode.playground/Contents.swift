import Foundation

// https://leetcode.com/problems/maximum-69-number/

func maximum69Number (_ num: Int) -> Int {
    let digits = String(num).compactMap { $0.wholeNumberValue }
    
    var previousMax = num
    
    for idx in (0..<digits.count) {
        var tempDigits = digits
        
        if tempDigits[idx] == 9 {
            tempDigits[idx] = 6
        } else {
            tempDigits[idx] = 9
        }
        
        let str = tempDigits.reduce("") { (result, val) -> String in
            return result + String(val)
        }
        
        if previousMax < Int(str)! {
            previousMax = Int(str)!
        }
    }

    return previousMax
}

maximum69Number(9669)

