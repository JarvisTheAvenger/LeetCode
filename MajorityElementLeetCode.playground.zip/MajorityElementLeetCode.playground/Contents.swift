import Foundation

// https://leetcode.com/problems/majority-element/

func majorityElement(_ nums: [Int]) -> Int {
    var dict = [Int:Int]()
    
    for num in nums {
        if let val = dict[num] {
            dict[num] = val + 1
        } else {
            dict[num] = 1
        }
    }
    
    return dict.sorted(by: { $0.value > $1.value}).first!.key
}

majorityElement([3,2,3])


