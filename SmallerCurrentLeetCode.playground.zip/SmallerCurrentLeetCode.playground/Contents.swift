import UIKit

func smallerNumbersThanCurrent(_ nums: [Int]) -> [Int] {
    var countArray = [Int]()
    
    for num in nums  {
        var count = 0
        
        for num1 in nums {
            if num1 < num {
                count += 1
            }
        }
        
        countArray.append(count)
    }
    
    return countArray
}

//smallerNumbersThanCurrent([8,1,2,2,3])


var a : Set<Int> = [1,2,3]

var b : Set<Int> = [1,2,3,4]

print(b.subtracting(a))
