import Foundation

// https://leetcode.com/problems/3sum/

func threeSum(_ nums: [Int]) -> [[Int]] {
    var dict = [Int: Bool]()
    
    for idx in (0..<nums.count) {
        let target = 0 - nums[idx]
        let nextIndex = idx + 1
        
        if nextIndex < nums.count-1 {
            
            for innerIdx in (nextIndex+1..<nums.count) {
                let num = nums[innerIdx]
                
                
                
                
            }
            
        }
    }
    
    return []
}

threeSum([-1, 2, 1, 0, -1, -4])
