import Foundation

func lastStoneWeight(_ bag: [Int]) -> Int {
    if bag.count == 1 { return bag.first!}
    if bag.count == 0 { return 0 }
    
    var bag = bag.sorted(by : >)
    
    var y = bag[0]
    let x = bag[1]
    
    bag.remove(at: 0)
    bag.remove(at: 0)
    
    if x == y {
        y = 0
    } else if x != y {
        y = y - x
    }
    
    if y > 0 {
        bag.append(y)
    }
    
    return lastStoneWeight(bag)
}

lastStoneWeight([2,2])



