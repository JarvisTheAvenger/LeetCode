import UIKit


func firstNonRepeatingChar(_ str : String) -> String {
    
    let chars = Array(str)
    
    var dict = [String : Int]()
    
    for char in chars {
        let key = String(char)
        if var value = dict[key] {
            value += 1
            dict[key] = value
        } else {
            dict[key] = 1
        }
    }

    return dict.sorted { $0.value < $1.value }.first!.key
}

firstNonRepeatingChar("aaabccdefe")
