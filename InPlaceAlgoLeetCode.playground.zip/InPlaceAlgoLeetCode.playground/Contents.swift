import Foundation


class Solution {
    func oddCells(_ n: Int, _ m: Int, _ indices: [[Int]]) -> Int {
        var set1 : Set<Int> = []
        var set2 : Set<Int> = []
        
        indices.forEach { (pair) in
            let x = pair[0]
            let y = pair[1]
            
            if set1.contains(x) {
                set1.remove(x)
            } else {
                set1.insert(x)
            }
            
            if set2.contains(y) {
                set2.remove(y)
            } else {
                set2.insert(y)
            }
        }
        
        
        return set1.count * m + set2.count * n - set1.count * set2.count * 2
    }
}
