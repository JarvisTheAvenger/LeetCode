import Foundation



func countElements(_ arr: [Int]) -> Int {
    var count = 0
    
    for element in arr {
        let increament = element + 1
        if arr.contains(increament) {
            count += 1
        }
    }
    
    return count
}

