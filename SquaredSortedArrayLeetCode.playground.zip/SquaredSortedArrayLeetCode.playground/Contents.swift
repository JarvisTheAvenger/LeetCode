import Foundation

func sortedSquares(_ array: [Int]) -> [Int] {
    var squared = [Int]()
    
    for num in array {
        squared.append(num)
    }

    return squared.sorted(by: <)
}

