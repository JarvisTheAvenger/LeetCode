import Foundation

//https://leetcode.com/explore/learn/card/data-structure-tree/134/traverse-a-tree/931/
public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

func levelOrder(_ root: TreeNode?) -> [[Int]] {
    var queue = [root]
    var visited = [Int]()
    
    while !queue.isEmpty {
        
    }
    
    
    return []
}
