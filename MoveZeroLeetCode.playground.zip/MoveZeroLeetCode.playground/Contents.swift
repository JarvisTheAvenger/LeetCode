import Foundation

func moveZeroes(_ nums: inout [Int]) {
    
    for idx in (0..<nums.count) {
        let num = nums[idx]
        
        if num == 0 {






            nums.append(num)
            nums.remove(at: idx)
        }
        
    }
}

var a = [0,0,1]
moveZeroes(&a)
