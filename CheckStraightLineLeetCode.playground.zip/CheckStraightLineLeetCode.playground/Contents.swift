import Foundation

func checkStraightLine(_ coordinates: [[Int]]) -> Bool {
    
    guard coordinates.count > 2 else { return true }
    
    let firstPoint = coordinates[0]
    let secondPoint = coordinates[1]
    
    let globalSlope = (secondPoint[1]-firstPoint[1]) / (secondPoint[0]-firstPoint[0])

    for i in (0..<coordinates.count) {
        if i < coordinates.count - 1 {
            let firstPoint = coordinates[i] // (x1,y1)
            let secondPoint = coordinates[i+1] //(x2,y2)
            
            let slope = (secondPoint[1]-firstPoint[1]) / (secondPoint[0]-firstPoint[0])
            
            print(slope)
            
            if slope != globalSlope {
                return false
            }
        }
    }
    
    return true
}

checkStraightLine([[-4,-3],[1,0],[3,-1],[0,-1],[-5,2]])

