import Foundation

// https://leetcode.com/problems/same-tree/

class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

//func isSameTree(_ p: TreeNode?, _ q: TreeNode?) -> Bool {
//    var pArray = [Int]()
//    var qArray = [Int]()
//
//    func traverseNode(_ r: TreeNode?, _ array : inout [Int]) -> [Int] {
//        guard let node = r else { return [] }
//
//        traverseNode(node.left, &array)
//        array.append(node.val)
//        traverseNode(node.right, &array)
//
//        return array
//    }
//
//    traverseNode(p, &pArray)
//    traverseNode(q, &qArray)
//
//    return pArray == qArray
//}



func isSameTree(_ p: TreeNode?, _ q: TreeNode?) -> Bool {
    if p == nil && q == nil {
        return true
    }
    
    if p == nil || q == nil {
        return false
    }
    
    if p!.val != q!.val {
        return false
    }
    
    return isSameTree(p?.right, q?.right) && isSameTree(p?.left, q?.left)
}


///print([1,nil,3] == [1,3,nil])

