import Foundation

public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init() { self.val = 0; self.left = nil; self.right = nil; }
    
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
    
    public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
        self.val = val
        self.left = left
        self.right = right
    }
}


func isCousins(_ root: TreeNode?, _ x: Int, _ y: Int) -> Bool {
    
    guard let root = root else { return false }
    
    var queue = [TreeNode]()
    
    queue.append(root)
    
    while true {
        
        var nodesCount = queue.count
        
        if nodesCount == 0 {
            break
        }
        
        var xNode : TreeNode?
        var yNode : TreeNode?
        
        while nodesCount > 0 {
            
            let current = queue.removeFirst()
            
            if current.val == x {
                xNode = current
            }
            
            if current.val == y {
                yNode = current
            }
            
            if current.left != nil {
                queue.append(current.left!)
            }
            
            if current.right != nil {
                queue.append(current.right!)
            }
            
            nodesCount -= 1
        }

        
    }
    
    return false
}


let leftNode = TreeNode(2, nil, nil)
let rightNode = TreeNode(3, nil, nil)



let node = TreeNode(1, leftNode, rightNode)
isCousins(node, 1, 3)

