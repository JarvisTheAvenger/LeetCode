import Foundation

// https://leetcode.com/problems/remove-outermost-parentheses/

func removeOuterParentheses(_ s: String) -> String {
    let arr = s.map(String.init)
    
    var open = 0
    var closed = 0
    
    var result = ""
    var str = [String]()
    
    for el in arr {
        str += [el]
        
        if el == "(" {
            open += 1
        } else {
            closed += 1
        }
        
        if open == closed {
            str.removeFirst()
            str.removeLast()
            
            result += str.joined()
            str = []
        }
    }
    
    return result
}

removeOuterParentheses("()(()())(((())))")

var a = "rahul"

a.removeFirst()
a.removeLast()

print(a)
