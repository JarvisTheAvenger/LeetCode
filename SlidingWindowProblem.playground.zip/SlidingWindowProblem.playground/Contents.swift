import Foundation

//func lengthOfLongestSubstring(_ s: String) -> Int {
//    let charArray = Array(s)
//    var max = 0
//
//    //guard charArray.count > 1 else { return 1 }
//
//    outerLoop : for outerIdx in (0..<charArray.count) {
//
//        var currentString = ""
//
//        currentString += String(charArray[outerIdx])
//
//        innerLoop : for innerIdx in (outerIdx+1..<charArray.count) {
//            let currentChar = charArray[innerIdx]
//
//            if currentString.contains(currentChar) {
//                break innerLoop
//            } else {
//                currentString += String(currentChar)
//            }
//        }
//
//        if currentString.count > max { max = currentString.count }
//    }
//
//    return max
//}



//    public int lengthOfLongestSubstring(String s) {
//        int n = s.length();
//        Set<Character> set = new HashSet<>();
//        int ans = 0, i = 0, j = 0;
//        while (i < n && j < n) {
//            // try to extend the range [i, j]
//            if (!set.contains(s.charAt(j))){
//                set.add(s.charAt(j++));
//                ans = Math.max(ans, j - i);
//            }
//            else {
//                set.remove(s.charAt(i++));
//            }
//        }
//        return ans;
//    }





class TreeNode {
    var val: Int
    var left: TreeNode?
    var right: TreeNode?
    init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

func isValidBST(_ root: TreeNode?) -> Bool {
    
    if let _root = root {
        
        if let leftVal = _root.left?.val, leftVal > _root.val {
            return false
        }
        
        if let rightVal = _root.right?.val, rightVal < _root.val {
            return false
        }
        
        isValidBST(_root.left)
        isValidBST(_root.right)
    }
    
    return true
}
