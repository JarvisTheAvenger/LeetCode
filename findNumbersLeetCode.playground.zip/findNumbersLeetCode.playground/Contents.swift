import Foundation

func findNumbers(_ numbers: [Int]) -> Int {
    return numbers.filter({String($0).count % 2 == 0}).count
}

findNumbers([12,345,2,6,7896])
