import Foundation

func plusOne(_ digits: [Int]) -> [Int] {
    var convertedArray = [Int]()
    
    var carry = 0
    
    for idx in stride(from: digits.count-1, through: 0, by: -1) {
        var value  = digits[idx]
        
        if idx == digits.count-1 {
            value = digits[idx] + carry + 1
        }
        
        if value >= 10 {
            carry = 1
            convertedArray.append(0)
        } else {
            convertedArray.append(value)
        }
    }
    
    if carry == 1 {
        convertedArray.append(1)
    }
    
    return convertedArray.reversed()
}

plusOne([9])


