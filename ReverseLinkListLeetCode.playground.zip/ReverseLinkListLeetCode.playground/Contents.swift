import Foundation

// https://leetcode.com/problems/reverse-linked-list/

public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}

func reverseList(_ head: ListNode?) -> ListNode? {
    
    var current = head
    var next : ListNode?
    var previous : ListNode?
    
    while current != nil {
        next = current?.next
        current?.next = previous
        previous = current
        current = next
    }

    return previous
}
