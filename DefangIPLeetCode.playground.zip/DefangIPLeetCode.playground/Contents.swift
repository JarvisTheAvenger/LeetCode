import Foundation


func defangIPaddr(_ address: String) -> String {
    var newString = ""
    
    for char in Array(address) {
        if char == "." {
            newString += "[.]"
        } else {
            newString += String(char)
        }
    }
    
    return newString
}



func subtractProductAndSum(_ n: Int) -> Int {
    let a = Array(String(n))
    var sum = 0
    var product = 1
    
    for char in a {
        let val = Int(String(char))!
        sum += val
        product *= val
    }
    
    return product - sum
}


func numJewelsInStones(_ J: String, _ S: String) -> Int {
    let jChars = Array(J)
    let sChars = Array(S)
    
    var jewelCount = 0
    
    for jChar in jChars {
        for sChar in  sChars {
            if sChar == jChar {
                jewelCount += 1
            }
        }
    }
    
    return jewelCount
}


public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}

func getDecimalValue(_ head: ListNode?) -> Int {
    var numString = ""
    
    var head1 = head
    
    while head1?.val != nil {
        numString += String(head1!.val)
        head1 = head1?.next
    }
    let num = Int(numString, radix:2)
    return num ?? 0
}

func toLowerCase(_ str: String) -> String {
    
    var result = ""
    
    for char in Array(str) {
        let val = UnicodeScalar(String(char))?.value
        let x = Int(val!)
        
        print(x)
        
        if x >= 65 && x <= 90 {
            let lowerVal = x + 32
            let lowerCased = String(UnicodeScalar(UInt32(lowerVal))!)
            result += lowerCased
        } else {
            result += String(char)
        }
        
    }
    
    return result
}

func freqAlphabets(_ s: String) -> String {
    
    let chars = Array(s)
    
    var index = 0
    var finalResult =  ""
    
    while index < chars.count {
        var str = String(chars[index])
        
        print(str)
        
        let checkIndex = index + 2
        
        if checkIndex <= chars.count {
            let hashChar = String(chars[checkIndex])
            if hashChar == "#" {
                str += String(chars[index+1])
                index += 2
            }
            
            print("yyy")
            finalResult += str
        } else {
            finalResult += str
        }
        
        index += 1
    }

    
    // let chars = s.components(separatedBy: "#")
   //  var array = [String]()
    
    
    
//    for c in chars {
//        let ascii = UInt32(c)! + UInt32(96)
//        array.append(String(UnicodeScalar(ascii)!))
//    }
    
    return ""
}



//freqAlphabets("10#11#12")
// "jkab"


func stackHeight2D(_ layers: Int) -> Double {
    let edge = Double(layers - 1)
    let value =  sqrt(edge) - sqrt(Double(edge))
    print(value+1)
    return 0
}

stackHeight2D(2)
