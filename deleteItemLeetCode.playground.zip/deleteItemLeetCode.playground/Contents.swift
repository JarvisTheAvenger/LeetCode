import Foundation

func removeElement(_ nums: inout [Int], _ val: Int) -> Int {

    nums.removeAll { (num) -> Bool in
        return num == val
    }
    
    return nums.count
}

var a = [3,2,2,3]
removeElement(&a, 2)
