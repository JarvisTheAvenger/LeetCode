import Foundation

func isHappy(_ n: Int) -> Bool {
    
    if String(n).count == 1 && (n == 1 || n == 7) {
        return true
    } else if String(n).count == 1 && n != 1 {
        return false
    }
    
    let digits = String(n).map { Int(String($0))! }
    
    let sum = digits.reduce(0) { (acc, num) -> Int in
        acc + (num*num)
    }
    
    return isHappy(sum)
}

isHappy(19)
