import Foundation

func findComplement(_ num: Int) -> Int {
    let binaryString = String(num, radix: 2)
    
    var str = ""
    
    for element in binaryString {
        str += element == "0" ? "1" : "0"
    }
    
    if let number = Int(str, radix: 2) {
       return number
    }
    
    return 1
}

//findComplement(5)


"RAHUL".capitalized
