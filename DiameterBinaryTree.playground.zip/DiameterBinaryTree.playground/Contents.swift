import Foundation

public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

func diameter(_ node : TreeNode?) -> Int {
    guard let node = node else { return 0 }
    
    let leftHeight = height(node.left)
    let rightHeight = height(node.right)
    
    let leftDiameter = diameter(node.left)
    let rightDiameter = diameter(node.right)
    
    let diameter = max((leftHeight+rightHeight+1), max(leftDiameter, rightDiameter))
    return diameter
}

func height(_ node: TreeNode?) -> Int {
    guard let node = node else { return 0 }
    
    let left = height(node.left)
    let right = height(node.right)
    
    let height = max(left, right) + 1
    
    return height
}

func diameterOfBinaryTree(_ root: TreeNode?) -> Int {
    return diameter(root)
}
