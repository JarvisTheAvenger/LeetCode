import Foundation

/*
 In insertion sort we devide array into two parts i.e sorted & unsorted array
 We pick the first element from the unsorted array add into the appropriate postion of the sorted array.
 We repeat the process until the unsorted array is empty.
 */


func insertionSort(_ array : inout [Int]) -> [Int] {
    
    for index  in (1..<array.count) {
        
        print(index)
        
        let temp = array[index]
        var j = index
        
        while (array[j-1] > temp && j > 0) {
            
            array[j] = array[j-1]
            
            j -= 1
            
        }
        
        array[j] = temp
        
        
    }
    
    
    return array
}


var unsortedArray = [30, 10, 50, 20, 60, 40]

insertionSort(&unsortedArray)


