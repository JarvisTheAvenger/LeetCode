import Foundation

func convert(_ s: String, _ numRows: Int) -> String {
    var arrayOfChar = Array(s)
    
    for index in (0..<numRows) {
       print(index)
        
        
        
        
    }
 
    return ""
}


convert("RAHULUMAP", 3) // RLPAUUAHM
