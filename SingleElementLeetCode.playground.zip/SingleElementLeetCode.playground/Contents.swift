import Foundation

func singleNonDuplicate(_ nums: [Int]) -> Int {
    var l = 0
    var r = nums.count - 1
    
    while l + 1 < r {
        let mid = (r - l) / 2 + l
        print(mid)
        if nums[mid] == nums[mid + 1] {
            // right side is ok
            if (r - mid + 1) % 2 == 0 {
                r = mid - 1
            } else {
                l = mid + 2
            }
            
        } else if nums[mid] == nums[mid - 1] {
            if (mid + 1 - l) % 2 == 0 {
                l = mid + 1
            } else {
                r = mid - 2
            }
        } else {
            return nums[mid]
        }
    }
    
    return nums[l]
}


singleNonDuplicate([1,1,2,3,3,4,4,8,8])
