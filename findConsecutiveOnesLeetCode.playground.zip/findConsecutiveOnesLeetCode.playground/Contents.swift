import Foundation

func findMaxConsecutiveOnes(_ nums: [Int]) -> Int {
    var left = 0, right = 0, res = 0
    
    for i in 0 ..< nums.count {
        if nums[i] == 1 {
            right = i + 1
        } else {
            res = max(res, right - left) // max (0, 5-0) => max(0,5) => 5
            left = right + 1 // 6
            right = left // 6
        }
        
        print(right,left, res)

    }
    
    res = max(res, right - left)
    
    return res
}




findMaxConsecutiveOnes([1,1,1,1,1,0,1,1,1,0])
