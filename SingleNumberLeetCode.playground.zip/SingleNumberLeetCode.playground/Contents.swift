import Foundation

//https://leetcode.com/submissions/detail/300986311/

func singleNumber(_ nums: [Int]) -> Int {
    var a = [Int:Int]()

    for el in nums {
        if let val = a[el] {
            a[el] = val + 1
        } else {
            a[el] = 1
        }
    }

    return a.filter({ $0.value == 1 }).first!.key
}

singleNumber([1,2,2])
