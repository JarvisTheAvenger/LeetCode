import Foundation

func maxProfit(_ prices: [Int]) -> Int {
 
    var profit = 0
    
    
    for price in prices {
        print(price)
    }
    
    return 0
}

maxProfit([7,1,5,3,6,4])
