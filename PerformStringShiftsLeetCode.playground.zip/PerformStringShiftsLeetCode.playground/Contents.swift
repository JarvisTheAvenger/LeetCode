import Foundation

func stringShift(_ s: String, _ shifts: [[Int]]) -> String {
    var rightShifts = 0
    var leftShifts = 0
    
    let characters = Array(s)
    var result = ""
    
    // Calculate total right and left shifts
    for shift in shifts {
        if shift.first! == 1 {
            rightShifts += shift[1]
        } else {
            leftShifts += shift[1]
        }
    }
    
    if rightShifts > leftShifts {
        let shiftsNeeded = (rightShifts - leftShifts) % characters.count
        let range = characters.count - shiftsNeeded
        result = String(characters[range..<characters.count] + characters[0..<range])
    } else if rightShifts < leftShifts {
        let shiftsNeeded = (leftShifts - rightShifts) % characters.count
        result = String(characters[shiftsNeeded..<characters.count] + characters[0..<shiftsNeeded])
    }
    
    return result
}

stringShift("abcdefg", [[1,1],[1,1],[0,2],[1,3]])

