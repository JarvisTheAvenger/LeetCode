import Foundation

func oddEven(_ number: Int) -> String {
    if number % 2 == 0 {
        return "Even"
    } else {
        return "Odd"
    }
    
}

oddEven(41654161)
