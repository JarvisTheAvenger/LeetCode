import Foundation

/*
 
 Selection sort takes two array one as sorted one and second unsorted.
 It starts from 0th position goes upto last element.
 It takes the min element from the unsorted array insert at the first position
 of the unsorted array. Then we increase the sorted array count by 1.
 
 */


func selectionSort(_ array : inout [Int]) -> [Int] {

    for outerIdx in (0..<array.count) {
        var minIdx = outerIdx
        
        for innerIdx in (outerIdx+1..<array.count) {
            if array[innerIdx] < array[minIdx] {
                minIdx = innerIdx
            }
        }
        
        if minIdx != outerIdx {
            array.swapAt(outerIdx, minIdx)
        }
        
    }
    
    return array
}


var unsortedArray = [30, 10, 50, 20, 60, 40]

let sortedArray = selectionSort(&unsortedArray)

print(sortedArray)
