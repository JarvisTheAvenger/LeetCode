import Foundation

class Solution {
    func addBinary(_ a: String, _ b: String) -> String {
        
        let aCharArray = Array(a)
        let bCharArray = Array(b)
        var aCounter = aCharArray.count-1
        var bCounter = bCharArray.count-1
        
        var carry = 0
        var result = ""
        
        repeat {
            
            var aVal = 0
            if aCounter > -1 { aVal = Int(String(aCharArray[aCounter])) ?? 0 }
            
            var bVal = 0
            if bCounter > -1 { bVal = Int(String(bCharArray[bCounter])) ?? 0 }
            
            let sum = aVal + bVal + carry
            carry = 0
            
            if sum == 2 {
                carry = 1
                result = "0" + result
            } else if sum == 3 {
                carry = 1
                result = "1" + result
            } else {
                result = String(sum) + result
            }
            
            aCounter -= 1
            bCounter -= 1
            
        } while (aCounter > -1 || bCounter > -1)
        
        if carry == 1 {  result = "1" + result }
        
        return result
    }
    
}

func addBinary(_ a: String, _ b: String) -> String {
    
    let aCharArray = Array(a)
    let bCharArray = Array(b)
    var aCounter = aCharArray.count-1
    var bCounter = bCharArray.count-1
    
    var carry = 0
    var result = ""
    
    repeat {
        
        var aVal = 0
        if aCounter > -1 { aVal = Int(String(aCharArray[aCounter])) ?? 0 }
        
        var bVal = 0
        if bCounter > -1 { bVal = Int(String(bCharArray[bCounter])) ?? 0 }
        
        let sum = aVal + bVal + carry
        carry = 0
        
        if sum == 2 {
            carry = 1
            result = "0" + result
        } else if sum == 3 {
            carry = 1
            result = "1" + result
        } else {
            result = String(sum) + result
        }
        
        aCounter -= 1
        bCounter -= 1
        
    } while (aCounter > -1 || bCounter > -1)
    
    if carry == 1 {  result = "1" + result }
    
    return result
}

print("Final Result", addBinary("1010", "1011"))

//Input: a = "1010", b = "1011"
//Output: "10101"

//Input: a = "11", b = "1"
//Output: "100"
