import Foundation

class Solution {
    func flipAndInvertImage(_ a: [[Int]]) -> [[Int]] {
        var reversedArray = [[Int]]()
        
        for el in a {
            reversedArray.append(el.reversed())
        }
        
        var result = [[Int]]()
        
        for innerArr in reversedArray {
            var invertedArray = [Int]()
            
            for el in innerArr {
                let val = el == 0 ? 1 : 0
                invertedArray.append(val)
            }
            
            result.append(invertedArray)
        }
        
        return result
    }
}


let sol = Solution()

let result = sol.flipAndInvertImage([[1,1,0],[1,0,1],[0,0,0]])

print(result)
