import UIKit


func bubbleSort(_ array : inout [Int]) -> [Int] {

    for outerIdx in (0..<array.count) {
        
        for innerIdx in (0..<array.count - outerIdx - 1) {
            if array[innerIdx] > array[innerIdx + 1] {
                array.swapAt(innerIdx, innerIdx + 1)
            }
        }
        
    }

    return array
}

var unsorted = [40, 20, 30, 60, 10, 50]

bubbleSort(&unsorted)

/*

40, 20, 30, 60, 10, 50
 
Iteration 1:
 
 i = 1
 
 20, 40, 30, 60, 10, 50
 20, 30, 40, 60, 10, 50
 20, 30, 40, 10, 60, 50
 20, 30, 40, 10, 50, 60
 
 
 i = 2
 
 
 

 
*/
