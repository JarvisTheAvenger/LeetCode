import Foundation

struct Stack {
    private var array = [String]()
    
    var count : Int {
        return array.count
    }
    
    var last : String? {
        return array.last
    }
    
    var elements : [String] {
        return array
    }
    
    mutating func push(_ s : String) {
        array.append(s)
    }
    
    mutating func pop() {
        array.removeLast()
    }

}

func isValid(_ possibleString: String) -> Bool {
    
    var stack = Stack()
    
    for c in possibleString {
        let c = String(c)
        
        if let last = stack.last {
            let pair = last + c
            
            if pair == "()" {
                stack.pop()
            } else {
                stack.push(c)
            }
            
        } else {
            stack.push(c)
        }
    }
    
    return stack.count == 0
}



func checkValidString(_ string: String) -> Bool {
    guard string.count > 0 else { return true }
    
    var bal = 0
    var buffer = 0
    
    let characters = Array(string)
    
    for i in (0..<characters.count) {
        
        let str = characters[i]
        
        if str == "*" { buffer += 1 }
        else if str == "(" { bal += 1 }
        else if str == ")" { bal -= 1 }
        
        if bal < -buffer { return false }
    }
    
    if bal > buffer { return false }
    
    buffer = 0
    bal = 0
    
    for i in (0..<characters.count).reversed() {
        
        let str = characters[i]
        
        if str == "*" { buffer += 1 }
        else if str == "(" { bal -= 1 }
        else if str == ")" { bal += 1 }
        
        if (bal < -buffer) { return false }
        
    }
    
    if (bal > buffer) { return false }
    
    return true
}


checkValidString(")(")


