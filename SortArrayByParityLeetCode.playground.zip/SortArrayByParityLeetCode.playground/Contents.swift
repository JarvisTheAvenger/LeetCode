import Foundation

// https://leetcode.com/problems/sort-array-by-parity/



func sortArrayByParity(_ array: [Int]) -> [Int] {
    var evenArray = [Int]()
    var oddArray = [Int]()
    
    for element in array {
        element % 2 == 0 ? evenArray.append(element) : oddArray.append(element)
    }
    
    return evenArray + oddArray
}

sortArrayByParity([3,1,2,4])


