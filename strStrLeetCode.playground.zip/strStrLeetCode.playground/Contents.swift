import Foundation

func strStr(_ haystack: String, _ needle: String) -> Int {
    guard needle.isEmpty == false else { return 0 }
    guard haystack.isEmpty == false else { return -1 }
    let (haystack, needle) = (Array(haystack), Array(needle))

    for i in 0..<haystack.count {
        var k = 0
        for j in i..<haystack.count {
            let (lhs, rhs) = (haystack[j], needle[k])

            guard lhs == rhs else { break }
            k += 1
            guard k != needle.count else { return i }
        }
    }

    return -1
}

strStr("hello", "ll")           //2
strStr("mississippi", "issip")  //4
strStr("", "")                  //0
strStr("", "a")                 //-1
strStr("a", "")                 //0
strStr("a", "a")                 //0

