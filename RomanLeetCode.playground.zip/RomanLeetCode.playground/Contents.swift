import Foundation


func romanToInt(_ s: String) -> Int {
    let str = Array(s).map(String.init)
    
    let dict = ["I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M": 1000]
    
    var sum = 0
    
    let idxArray = (0...str.count-1).reversed()
    
    for idx in idxArray {
        let romanLiteral = str[idx]
        let currentValue = dict[romanLiteral]!
        print(str[safe: idx-1])
    }
    
    return sum
}










extension Array {
    subscript (safe index: Index) -> Element? {
        return 0 <= index && index < count ? self[index] : nil
    }
}


romanToInt("IX")
