import Foundation

//https://leetcode.com/problems/squares-of-a-sorted-array/


func sortedSquares(_ a: [Int]) -> [Int] {
    return a.map({ $0*$0 }).sorted()
}

sortedSquares([-4,-1,0,3,10])
