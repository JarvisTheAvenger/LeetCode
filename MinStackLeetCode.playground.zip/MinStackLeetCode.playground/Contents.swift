import Foundation

class MinStack {
    /** initialize your data structure here. */
    var a = [Int]()
    
    init() {
        
    }
    
    func push(_ x: Int) {
        a.append(x)
    }
    
    func pop() {
      a.removeLast()
    }
    
    func top() -> Int {
        a.last ?? 0
    }
    
    func getMin() -> Int {
        a.min() ?? 0
    }
}


let a = MinStack()
