import Foundation

// https://leetcode.com/problems/number-of-steps-to-reduce-a-number-to-zero/

func numberOfSteps (_ num: Int) -> Int {
    var counter = 0
    var num = num
    
    while num > 0 {
        counter += 1
        num % 2 == 0 ? (num /= 2) : (num -= 1)
    }
 
    return counter
}
