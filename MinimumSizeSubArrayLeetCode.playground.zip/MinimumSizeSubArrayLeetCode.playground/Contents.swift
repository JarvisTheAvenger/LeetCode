import Foundation

// https://leetcode.com/problems/minimum-size-subarray-sum/

func minSubArrayLen(_ s: Int, _ nums: [Int]) -> Int {
    var minArray = [Int]()
    
    var i = 0
    var j = 0
    
    while i < nums.count {

         // Found result equivalent to target
         i += 1
        
        // Else go on...
        j += 1
        
        
        
    }
    
    return 0
}


