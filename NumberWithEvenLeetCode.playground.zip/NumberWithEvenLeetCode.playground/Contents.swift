import Foundation

// https://leetcode.com/problems/find-numbers-with-even-number-of-digits/

func findNumbers(_ nums: [Int]) -> Int {
    var count = 0
    
    for number in nums {
        let strArr = Array(String(number))
        
        if strArr.count % 2 == 0 {
            count += 1
        }
    }
    
    return count
}

findNumbers([555,901,482,1771])
