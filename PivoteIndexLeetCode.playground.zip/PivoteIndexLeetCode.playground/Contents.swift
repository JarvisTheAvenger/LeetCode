import Foundation



func plusOne(_ digits: [Int]) -> [Int] {
    var convertedArray = [Int]()
    
    var carry = 0
    
    for idx in (digits.count-1...0) {
        
        if idx == digits.count - 1  {
            let value = digits[idx] + 1
            if value > 10 {
                carry = 1
                
            }
        }
        else {
            
        }
        
       convertedArray.append(1)
    }
    
    return convertedArray
}


plusOne([4,3,2,1])

/*
 
 [2:6]
 
 
 */
