import Foundation

//https://leetcode.com/problems/valid-parentheses/solution/

struct Stack {
    private var array = [String]()
    
    var count : Int {
        return array.count
    }
    
    var elements : [String] {
        return array
    }
    
    mutating func push(_ s : String) {
        array.append(s)
    }
    
    mutating func pop() {
        array = array.dropLast()
    }
    
    func last() -> String? {
        array.last
    }
}


func isValid(_ string: String) -> Bool {
    guard string.count > 0 else { return true }
    
    let string = string.map { String($0) }
    
    var stack = Stack()
    
    for c in string {
        
        if let last = stack.last() {
            let pair = last + c
            
            if pair == "{}" || pair == "[]" || pair == "()" {
                stack.pop()
            } else {
                stack.push(c)
            }
            
        } else {
            stack.push(c)
        }
    }
    
    return stack.count == 0
}


isValid("()[]{}")
