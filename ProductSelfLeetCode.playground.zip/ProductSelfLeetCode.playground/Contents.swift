import Foundation

func productExceptSelf(_ nums: [Int]) -> [Int] {
    
    let length = nums.count
    var result = [1]
    
    for i in (1..<length) {
        result.insert(nums[i-1] * result[i-1], at: i)
    }
    
    var right = 1
    
    for i in (0..<length).reversed() {
        result[i] = result[i] * right
        right *= nums[i]
    }
    
    return result
}

productExceptSelf([1,2,3,4])


