import Foundation

func productInputArray(_ a : [Int]) -> [Int] {
    var result = [Int]()
    
    for idx in (0..<a.count) {
        var product = 1
        
        for innerIdx in (0..<a.count) {
            if idx != innerIdx {
                product *= a[innerIdx]
            }
        }
        
        result.append(product)
    }
    
    return result
}


productInputArray([3,2,1])
