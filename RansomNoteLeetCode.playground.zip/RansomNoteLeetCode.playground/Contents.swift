import Foundation

func canConstruct(_ ransomNote: String, _ magazine: String) -> Bool {
    
    if ransomNote.isEmpty && magazine.isEmpty { return true }
   
    var dict = [Character:Int]()
    
    for el in ransomNote {
        if let value = dict[el] {
            dict[el] = value + 1
        } else {
            dict[el] = 1
        }
    }
    
    for character in magazine {
        if let val = dict[character] {
            if val == 1 {
                dict[character] = nil
            } else {
                dict[character] = val - 1
            }
        }
        
        if dict.isEmpty {
            return true
        }
    }
    
    return false
}

canConstruct("aa", "aab")
