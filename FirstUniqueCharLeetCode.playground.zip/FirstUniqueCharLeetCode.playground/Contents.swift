import Foundation

func firstUniqChar(_ s: String) -> Int {
    var arr = Array(repeating: 0, count: 26)
    let a = Int("a".unicodeScalars.first!.value)
    for i in s.unicodeScalars {
        let index = Int(i.value) - a
        arr[index] += 1
    }
    var ip = 0
    for i in s.unicodeScalars {
        let index = Int(i.value) - a
        if arr[index] == 1 {
            return ip
        }
        ip += 1
    }
    return -1
}

firstUniqChar("rahul")
