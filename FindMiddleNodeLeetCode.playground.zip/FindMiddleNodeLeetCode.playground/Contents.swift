import Foundation



public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}

class Solution {
    func middleNode(_ head: ListNode?) -> ListNode? {
        var nodes = [ListNode?]()
        var head = head
        
        while head != nil {
            nodes.append(head)
            head = head?.next
        }
        
        return  nodes[nodes.count/2]
    }
}


let a : Int = 5 / 2
