import Foundation

 public class TreeNode {
     public var val: Int
     public var left: TreeNode?
     public var right: TreeNode?
     public init(_ val: Int) {
         self.val = val
         self.left = nil
         self.right = nil
     }
 }

func preorderTraversal(_ root: TreeNode?) -> [Int] {
    var array = [Int]()
    
    func traverse(_ node : TreeNode?) {
        guard node != nil else {
            return
        }
        
        array.append(node!.val)
        traverse(node!.left)
        traverse(node!.right)
    }
    
    traverse(root)
    
    return array
}


